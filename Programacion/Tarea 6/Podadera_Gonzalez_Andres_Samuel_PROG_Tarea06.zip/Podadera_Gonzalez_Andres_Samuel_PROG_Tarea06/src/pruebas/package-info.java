/**
 * Proporciona las clases o programas de prueba para las clases del paquete
 * <code>libreria</code> y subpaquetes.
 *
 * @author profe
 */
package pruebas;
