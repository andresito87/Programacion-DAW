/**
 * Proporciona las clases o programas de prueba para las clases del proyecto Tienda.
 * @author profe
 */
package tarea07.pruebas;