/**
 * Paquete principal de clases para el proyecto Tienda.
 * Incorpora las clases <code>Compra</code>, <code>TicketCompra</code> y <code>Tienda</code>.
 * @author profe
 */
package tarea07.tienda;
