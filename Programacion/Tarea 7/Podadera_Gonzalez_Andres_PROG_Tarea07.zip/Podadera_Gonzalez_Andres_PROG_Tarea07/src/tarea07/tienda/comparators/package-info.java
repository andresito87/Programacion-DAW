/**
 * Paquete de clases <code>Comparator</code> para el proyecto Tienda.
 * Incorpora diversos criterios de comparación para objetos de tipo <code>TicketCompra</code>.
 * @author profe
 */
package tarea07.tienda.comparators;
